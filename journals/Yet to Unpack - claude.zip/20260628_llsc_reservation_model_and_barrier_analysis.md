<!--
EmulatR V4 -- LL/SC Reservation Model: HRM-Grounded Fidelity Record + Barrier Deadlock Analysis
Project: EmulatR (Alpha 21264 / EV67 emulator), V4 active tree
Architect: Timothy Peer.  AI collaboration: Claude / Anthropic.
Date: 2026-06-28.  Source: claude.ai web (analysis/design only); Cowork executes
against the live tree at D:\EmulatR\EmulatRAppUniV4\Emulatr.
Purpose: ground the Phase-3 LL/SC interlock (SMP inventory plan Step 4) in the
21264/EV67 HRM. Closes the open "confirm granule vs 21264 HRM" CONFIRM; retracts
the per-granule owner-table floated in the prior session; formalizes why deadlock
cannot occur at CPU+N; adds the Restriction 23 same-CPU clearing ledger item; pins
the STx_C sync-point resolution rule. NO CODE LANDED THIS SESSION (plan only).
ASCII(128) only.
-->

# LL/SC Reservation Model -- HRM-Grounded Fidelity Record + Barrier Deadlock Analysis

**Date:** 2026-06-28
**Status:** DESIGN / FIDELITY RECORD. No code landed this session. This feeds
**Step 4 (Phase 3, "THE CLIFF")** of `journals/20260628_smp_harness_inventory_and_completion_plan.md`.
**Predecessors (read first):**
- `journals/20260628_smp_harness_inventory_and_completion_plan.md` (the home doc; Step 4 + the test plan)
- `journals/20260618_smp_secondary_cpu_bringup_design.md` (Phase 3 = the cliff)
- `journals/20260619_next_steps_alphacpuagent_gap.md` (item #4, LL/SC split FSM)

---

## 0. TL;DR

The Phase-3 plan's shape (per-CPU `lock_flag` + `lock_physical_address`, cross-CPU
invalidation on any store, micro-test before trusting firmware SMP) is CORRECT and
faithful. This session grounds it in the 21264/EV67 HRM and closes four open items:

1. **GRANULE CONFIRMED = 64 bytes** (the EV6 Dcache block). Closes the SMP plan's
   open CONFIRM at Step 4 ("confirm granule vs 21264 HRM"). Mask = `pa & ~0x3F`.
   NOT the 16-byte architectural floor -- model the EV6 coherence block.
2. **Per-CPU register model is the FAITHFUL one. RETRACT the per-granule owner-table**
   floated in the prior (free-account) session. The O(N) cross-CPU `clearLine` walk
   is not overhead to optimize away -- it IS the invalidating-probe broadcast the
   HRM describes.
3. **Deadlock is impossible at CPU+N by construction** (LL/SC never blocks and never
   holds). The only failure mode is livelock, which is the guest's concern; the
   emulator's sole correctness duty is "never report a false STx_C success."
4. **The barrier risk is determinism, not deadlock.** Closed by two invariants:
   (a) no agent ever blocks mid-quantum on a reservation; (b) STx_C resolves at
   `syncPhase`, in fixed agent order, against committed state.

New ledger item: **Restriction 23 same-CPU clearing** (an owning CPU's own
intervening LD/ST invalidates its reservation) -- marked `_PROVISIONAL`, model-now
vs shelve is a fidelity-completeness call, not a boot blocker.

---

## 1. Grounded silicon facts (21264/EV67 HRM, project copy)

Source file: `Alpha_21264-EV67_Microprocessor_Hardware_Reference_Manual.txt`
(line refs are into that text copy so Cowork can re-verify).

**Section 4.6 "Lock Mechanism" (~line 6543).** The headline that reframes the whole
question:

- "The 21264/EV67 does not contain a dedicated lock register, nor are system
  components required to do so." There is NO lock register, NO flag buffer, NO
  PA-range table on real silicon. The reservation IS the cache-line state.
- LDx_L: data is accessed from Dcache/Bcache; on miss, RdBlk from memory; the
  associated cache line is filled into the Dcache in the CLEAN state.
- STx_C: succeeds IFF its associated cache line is still present in the Dcache and
  can be made writable; otherwise it fails.
- Why it is coherent (four items): (1) LDx_L processed in-order w.r.t. its STx_C;
  (2) once locked, no internal agent evicts the block as a side effect; (3) any
  external agent updating the block MUST use an invalidating probe; (4) the SYSTEM
  is the only agent with enough information for fairness and liveness -- the 21264
  generates external commands only for nonspeculative STx_C, and once the system
  signals success, must faithfully update the Dcache. The system is entirely
  responsible for item 3; the 21264 plays an active role in 1, 2, 4.

**Granule = 64-byte cache block (~line 2614).** "The data cache (Dcache) is a 64KB,
2-way set-associative, virtually indexed, physically tagged, write-back, read/write
allocate cache with 64-byte blocks." The reservation granularity is therefore the
64-byte Dcache line (coarser than the 16-byte architectural minimum; any correct
guest tolerates the coarser block, and this is the faithful EV6 behavior).

**Restriction 23 -- same-CPU intervening op (HRM Appendix D, ~line 19771).** "A
HW_ST/P/CONDITIONAL will not clear the lock flag ... In the 21264/EV67, a
store-conditional is forced to fail if there is an intervening memory operation
between the store-conditional and its address-matching LDxL." The intervening ops
that force failure: LDL/Q/F/G/S/T, STL/Q/F/G/S/T, LDQ_U (not to R31), STQ_U.
ABSENT (do NOT clear): HW_LD (any), HW_ST (any), ECB, WH64.

---

## 2. The decision: per-CPU register model, owner-table RETRACTED

Because the emulator does NOT simulate the full Dcache coherence FSM, the
reservation must be REINTRODUCED explicitly as a faithful stand-in for "is my
locked line still present and writable." The faithful shape is exactly what the
Phase-3 plan and the existing `LockArbiter`/`LockMonitor` already are: one
reservation per CPU + a broadcast invalidation.

**Prior-session correction (on the record):** the per-granule owner-table (the
"O(1)" idea) is RETRACTED. Grounded in 4.6, the per-CPU register + `clearLine`
fan-out is MORE faithful -- `clearLine` IS the invalidating-probe broadcast. The
owner-table also needs an auxiliary "current granule per CPU" anyway to enforce
one-reservation-per-CPU (a second LDx_L must drop the first), so it is not even
simpler. At N=2..4 the O(N) walk is free. Keep the per-CPU registers.

Design shape (NOT final code -- Cowork confirms the live interface, see Section 7):

    struct Reservation {
        bool     valid;        // stands in for "locked line present + writable"
        uint64_t granulePa;    // pa & ~0x3F  (64-byte EV6 Dcache block)
    };
    Reservation res[N];        // indexed by cpuId; ONE slot, not a range cache

    loadLocked(cpu, pa):
        res[cpu] = { valid = true, granulePa = pa & ~0x3F }

    storeConditional(cpu, pa) -> bool:
        ok = res[cpu].valid && res[cpu].granulePa == (pa & ~0x3F)
        res[cpu].valid = false                 // STx_C always clears own flag
        if ok: perform-the-write; clearLine(pa, exceptCpu = cpu)
        return ok

    clearLine(pa, byCpu):                       // = the invalidating-probe broadcast
        g = pa & ~0x3F
        for each j != byCpu:
            if res[j].valid && res[j].granulePa == g: res[j].valid = false
        // called on EVERY store to that granule: STx, successful STx_C, AND DMA

---

## 3. Reservation single-source-of-truth -- CONFIRM (load-bearing)

There are TWO reservation structures named across the docs and they MUST be
reconciled before any STx_C path edit:

- `memoryLib::LockMonitor` (via `GuestMemory::lockMonitor()`) -- named in project
  memory as the reservationState SINGLE SOURCE OF TRUTH, with cross-CPU
  `clearLine(pa)` already wired; deprecated `CpuState` reservation fields flagged
  for removal.
- `LockArbiter` in `schedLib/SmpHarness.h` -- the SMP inventory plan describes this
  as the "per-CPU LDx_L/STx_C reservation table (no host atomics)" backing the
  harness micro-tests.

**CONFIRM-1 (Cowork, read-only first):** Which is canonical for the REAL agent
path? Does `AlphaCpuAgent`'s STx_C route through `LockMonitor` (memoryLib) or
`LockArbiter` (schedLib)? Are these the same structure under two names, a wrapper,
or two separate tables that must be unified? Resolve this BEFORE writing the
interlock -- a split here is silent corruption (one structure invalidated, the
other consulted). If they are separate, the unification target is `LockMonitor`
(the documented single source of truth) with `LockArbiter` either delegating to it
or being retired.

---

## 4. Deadlock is impossible at CPU+N (the formal argument)

The CPU+N deadlock worry is retired by construction, independent of CPU count:

- LL/SC is NON-BLOCKING. LDx_L always completes (it is just a load). STx_C
  completes immediately as success OR fail -- it never waits, never spins inside
  the emulator.
- A reservation is NOT a held resource that blocks another CPU. It is a hint that
  another CPU's store silently invalidates. Nobody waits on it; nobody is excluded
  by it.
- Deadlock requires a circular wait over held-and-awaited resources. With no
  blocking and no holding, that cycle cannot form. Therefore no deadlock at +2, +3,
  or +N.

HRM item 4 assigns liveness to the SYSTEM and forward-progress to SOFTWARE (the
restriction list). So the residual failure mode is LIVELOCK -- two+ CPUs
ping-ponging invalidations so neither STx_C ever lands. On iron this is bounded by
the coherence race and software backoff. In the emulator, guest livelock is the
GUEST'S concern (or a guest bug). The emulator's ONLY correctness duty is to never
report a FALSE SUCCESS -- an STx_C that writes 1 to Ra when the reservation was in
fact invalidated. The per-CPU register + `clearLine` model guarantees that at any
CPU count.

NOTE the diagnostic trap (already on the ledger): livelock presents IDENTICALLY to
a boot hang. That is why the micro-test (Section 6) is non-negotiable before any
firmware SMP result is trusted.

---

## 5. The barrier / quantum interaction (the REAL risk: determinism)

The `std::barrier` cannot deadlock FROM LL/SC as long as one invariant holds:

- **INVARIANT B1: no agent ever blocks mid-quantum on a reservation.** STx_C
  resolves synchronously to success/fail within the agent's own step; the guest's
  retry spin is ORDINARY instructions executed ACROSS quanta, never an
  emulator-internal stall. So every agent always arrives at the barrier, so the
  barrier always releases. State B1 explicitly as a property of the LL/SC seam.

The actual risk at quantum > 1 is DETERMINISM of STx_C resolution. An STx_C
executed mid-quantum cannot know its final answer at execution time, because
another CPU's store that is earlier in wall-clock but LATER in commit order may
invalidate it. Therefore:

- **INVARIANT B2: STx_C does not resolve optimistically mid-quantum.** It is staged
  as an Effect and ADJUDICATED at `syncPhase`, in fixed agent order, against the
  COMMITTED reservation table. This is the existing item-#4 "SC pending" FSM (stage
  `StoreCond`, yield at the LL->SC boundary, read the ack next quantum, write Ra).
  Resolve there and ThreadedDriver yields BIT-IDENTICAL results to SequentialDriver.

The mapping to keep in mind: per-CPU reservation = the abstracted cache-line state;
`clearLine` = the invalidating probe; `syncPhase` = HRM item-4's "system is the
serialization point for fairness/liveness." B2 is just "let the serialization point
do the adjudication," which is what the determinism contract already requires.

---

## 6. The micro-test (extends SMP plan Step 4, test `ll_sc_contention`)

doctest `CHECK` only (exceptions disabled in V4). Drive `MockCpuAgent` /
`LockArbiter` (or `LockMonitor` after CONFIRM-1) directly -- do NOT rely on
firmware. Two cases:

**6a. Two-CPU correctness (the SMP-plan baseline).** 2 CPUs contend on one granule
for N iters. CHECK: exactly one holder at any time; total successful acquisitions
== N; no double-acquire; no false success. (This is the plan's existing spec.)

**6b. Three-CPU contention / quantum floor (NEW -- the livelock probe).** 2
contenders + 1 invalidator on a shared granule. CHECK: no false success at any CPU
count; deterministic single winner per contended round under SequentialDriver;
under ThreadedDriver the result is bit-identical to Sequential for a given quantum.
PURPOSE: 6b is the EMPIRICAL probe for the minimum safe quantum -- the smallest
quantum at which Threaded still matches Sequential. Two-CPU tests do not expose the
window where a coarse quantum hides an invalidation; 6b does. This measured floor,
not a calculated one, is what gates the threaded path for >1 agent.

Guardrail (from the SMP plan, restated): 6a AND 6b must pass before any firmware
SMP result is trusted; `determinism_equivalence` stays green at every step.

---

## 7. Concrete Cowork task map (accessible, ordered)

This is the next-session executable sequence. Steps 1-2 are READ-ONLY (no sign-off
needed). Step 3 (the micro-test) is a low-risk landable artifact. Steps 4-5 are the
seam edits and are GATED on architectural sign-off per discuss-before-code.

1. **[READ-ONLY] Resolve CONFIRM-1 (Section 3).** Report the live interfaces of
   `memoryLib::LockMonitor` (`GuestMemory::lockMonitor()`) and `LockArbiter`
   (`schedLib/SmpHarness.h`): method signatures, who calls each, whether
   `AlphaCpuAgent`'s STx_C path touches one or both. State which is canonical.
2. **[READ-ONLY] Confirm the granule constant + the STx_C staging point.** Confirm
   nothing in the live tree already hardcodes a non-0x40 granule. Confirm where
   `Effect::StoreCond` is staged and where `syncPhase` would adjudicate it
   (the EX-stage / MEM-stage / WB-stage seam, per BoxResult discipline).
3. **[LANDABLE] Write the micro-test** (Section 6, 6a + 6b) as
   `tests/schedLib/smp_harness_tests.cpp` additions (or a new file under
   `tests/schedLib/`), `CHECK`-only, against the canonical structure from step 1.
   This validates the EXISTING `LockArbiter`/`LockMonitor` semantics and gives the
   quantum-floor measurement vehicle BEFORE any seam edit. ADR-0001 header; include
   guards; hex case labels if any.
4. **[GATED on sign-off] Set the granule mask** to `pa & ~0x3F` at the reservation
   structure, with the HRM citation in the header block (4.6 + the Dcache 64-byte
   line). Confirm `loadLocked`/`storeConditional`/`clearLine` align granule
   identically. This CONFIRMED value is NOT `_PROVISIONAL`.
5. **[GATED on sign-off] Wire the cross-CPU invalidation completely:** `clearLine`
   called on STx, successful STx_C, AND the Pchip DMA write path (SMP plan Step 4
   "DMA participation"). Verify B1 (no mid-quantum block) and B2 (sync-point
   adjudication) hold.

DEFERRED / ledger (do NOT chase inline):
- **Restriction 23 same-CPU clearing.** Model an owning CPU's own intervening LD/ST
  (the listed types only; NOT HW_LD/HW_ST/ECB/WH64) as invalidating its own
  reservation. Correct guest LL/SC sequences have no intervening mem op, so this
  rarely bites; it is a fidelity-completeness item. Mark `_PROVISIONAL` until
  modeled. Decision (model-now vs shelve) is Tim's.

---

## 8. VERIFY / CONFIRM ledger

- **CONFIRM-1 (BLOCKING):** `LockMonitor` (memoryLib) vs `LockArbiter` (schedLib) --
  which is canonical; do they unify; does the real agent path route correctly.
  Must resolve before any STx_C seam edit (Section 3).
- **CONFIRM-2:** the live `Effect::StoreCond` staging site + the `syncPhase`
  adjudication site (Section 7 step 2).
- **VERIFY-1:** no existing granule constant in the tree contradicts 0x40.
- **VERIFY-2:** `EMULATR_DISPATCH` gate state -- the SMP inventory plan flags that a
  later commit may have made the dispatcher path unconditional. Confirm against the
  live `Machine::run()` before relying on the toggle (carried from the SMP plan).

---

## 9. Out of scope (do NOT chase here)

- Phase 4 (IPI), Phase 5 (secondary rendezvous), Phase 6 (snapshot extension) --
  downstream of this interlock; see the SMP inventory plan.
- The 264DP/SYSVAR badge and the HWRPB two-gate hand-off work -- a separate track
  (`journals/20260628_hwrpb_handoff_gates_plan.md`); not on this critical path.
- MMIO threaded-path serialization -- flagged in the SMP plan Step 2/#5; relevant
  only at Threaded + >1 agent; not part of the reservation model itself.

---

## 10. CONFIRMED vs DISTILLED (provenance)

- CONFIRMED against HRM (project copy), citations in Section 1: no lock register;
  reservation = cache-line presence+writability; granule = 64-byte Dcache block;
  system owns invalidating probes + fairness/liveness; Restriction 23 intervening-op
  list.
- DISTILLED / design judgment (not a single HRM quote): the per-CPU register vs
  owner-table choice; the deadlock-impossibility argument; the B1/B2 barrier
  invariants; the 3-CPU quantum-floor micro-test. These follow FROM the HRM facts
  plus the harness's determinism contract, but are engineering decisions to confirm
  in review, not transcribed HRM text.
