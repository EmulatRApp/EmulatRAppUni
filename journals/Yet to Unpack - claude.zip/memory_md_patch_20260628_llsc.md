<!--
EmulatR V4 -- memory.md SURGICAL PATCH BRIEF (LL/SC reservation model session)
Date: 2026-06-28.  Source: claude.ai web.  Apply against the live memory.md.
This is a PATCH BRIEF, not a file. Cowork: verify line numbers against the live
memory.md before editing (the line refs below are approximate, from the uploaded
copy). Prefer surgical Edit over rewrite. ASCII(128) only.
-->

# memory.md patch brief -- LL/SC reservation model (2026-06-28)

Three edits. (A) insert a new dated entry at the TOP entry position
(most-recent-at-top, immediately under the file header / above the newest existing
entry). (B) replace the near-top Phase-3 "NEXT" bullet cluster. (C) replace the
deferred-list Phase-3 bullet. (B) and (C) update imprecise text + point at the new
journal.

================================================================================
EDIT A -- INSERT new entry at top entry position
================================================================================

## 2026-06-28 -- LL/SC reservation model HRM-grounded; granule CONFIRMED; deadlock retired

**Headline: grounded the Phase-3 LL/SC interlock (SMP plan Step 4 "THE CLIFF") in
the 21264/EV67 HRM. Closed the open "confirm granule" CONFIRM; RETRACTED the
per-granule owner-table; formalized why deadlock cannot occur at CPU+N; added the
Restriction 23 same-CPU clearing ledger item. NO CODE LANDED.** Full record:
`journals/20260628_llsc_reservation_model_and_barrier_analysis.md`.

- **NO LOCK REGISTER ON EV6 (HRM 4.6, ~line 6543).** The reservation IS the Dcache
  cache-line state: STx_C succeeds iff its line is still present + writable. There
  is no flag buffer, no PA-range table, no central directory on silicon. The
  emulator REINTRODUCES an explicit per-CPU `(valid, granulePa)` purely as a
  faithful stand-in for that line state.
- **GRANULE CONFIRMED = 64 bytes** = the EV6 Dcache block (HRM ~line 2614, "64KB
  2-way ... 64-byte blocks"). Mask `pa & ~0x3F`. NOT `_PROVISIONAL`; NOT the 16-byte
  architectural floor. This CLOSES the SMP plan Step 4 CONFIRM "confirm granule vs
  21264 HRM".
- **OWNER-TABLE RETRACTED.** The prior-session per-granule owner-table idea is
  withdrawn: the per-CPU register + cross-CPU `clearLine` fan-out is MORE faithful
  -- `clearLine` IS the invalidating-probe broadcast (HRM 4.6 item 3). Keep what
  `LockArbiter`/`LockMonitor` already are. O(N) walk at N=2..4 is free.
- **DEADLOCK IMPOSSIBLE at CPU+N by construction.** LL/SC never blocks, never holds
  -> no circular wait -> no deadlock at any CPU count. Residual failure is LIVELOCK
  (guest's concern; HRM item 4 = system owns liveness, software owns progress).
  Emulator's ONLY duty: never report a FALSE STx_C success. (Livelock presents
  identically to a boot hang -> micro-test non-negotiable.)
- **BARRIER RISK = DETERMINISM, not deadlock.** Two invariants close it. B1: no
  agent ever blocks mid-quantum on a reservation (guest retry is ordinary
  instructions across quanta) -> every agent always reaches the `std::barrier`. B2:
  STx_C resolves at `syncPhase`, fixed agent order, against COMMITTED state (the
  existing "SC pending" FSM) -> ThreadedDriver bit-identical to Sequential.
  Mapping: reservation = cache-line state; `clearLine` = invalidating probe;
  `syncPhase` = HRM item-4 serialization point.
- **NEW LEDGER ITEM: Restriction 23 (HRM App. D, ~line 19771).** An owning CPU's own
  intervening LD/ST (LDL/Q/F/G/S/T, STL/Q/F/G/S/T, LDQ_U!=R31, STQ_U; NOT
  HW_LD/HW_ST/ECB/WH64) forces its STx_C to fail. Correct guests do not trip it ->
  fidelity-completeness item, `_PROVISIONAL`, model-now vs shelve is Tim's call.
- **BLOCKING CONFIRM for next session:** reconcile `memoryLib::LockMonitor` (doc'd
  single source of truth, `clearLine` wired) vs `LockArbiter` in
  `schedLib/SmpHarness.h` (harness reservation table) -- which is canonical, do they
  unify, does `AlphaCpuAgent` STx_C route correctly. Resolve BEFORE any seam edit; a
  split = silent corruption. See the journal Section 3 + the ordered Cowork task map
  (Section 7: read-only audit -> micro-test 6a/6b landable -> gated seam edits).

================================================================================
EDIT B -- REPLACE the near-top Phase-3 "NEXT" cluster (uploaded ~lines 163-167)
================================================================================

FIND (current text):
- **NEXT = PHASE 3: LL/SC cross-CPU interlock (THE cliff).** Per-CPU lock_flag/
  lock_physical_address; any store by any agent clears other CPUs' flag on that
  granule; real LockArbiter backing; a non-negotiable contention micro-test; never
  yield MID-INSTRUCTION but interleave at the LL/SC boundary.  See the ledger's
  Phase-2-CLOSED handoff + journals/20260618_smp_secondary_cpu_bringup_design.md.

REPLACE WITH:
- **NEXT = PHASE 3: LL/SC cross-CPU interlock (THE cliff).** Per-CPU lock_flag/
  lock_physical_address; granule CONFIRMED = 64 bytes (EV6 Dcache block, `pa & ~0x3F`);
  any store (STx, STx_C, DMA) by any agent clears other CPUs' flag on that granule
  via clearLine (= the invalidating-probe broadcast); non-negotiable contention
  micro-test (2-CPU + 3-CPU quantum-floor); never yield MID-INSTRUCTION (interleave
  at the LL->SC boundary); STx_C adjudicated at syncPhase in fixed agent order.
  Deadlock impossible by construction; only duty = no false STx_C success. HRM-
  grounded design + ordered Cowork task map (incl. the BLOCKING LockMonitor-vs-
  LockArbiter CONFIRM): `journals/20260628_llsc_reservation_model_and_barrier_analysis.md`.
  See also journals/20260618_smp_secondary_cpu_bringup_design.md.

================================================================================
EDIT C -- REPLACE the deferred-list Phase-3 bullet (uploaded ~lines 707-714)
================================================================================

FIND (current text):
  - **Phase 3 -- LL/SC cross-CPU interlock (THE cliff):** per-CPU
    `lock_flag`/`lock_physical_address`; any store (STx, STx_C, or DMA) by any
    agent clears other CPUs' lock_flag on that granule; LockArbiter gets real
    backing. Dedicated contention micro-test is non-negotiable (both-win =
    corruption; livelock = looks like the current hang). LL/SC split FSM:
    never yield MID-INSTRUCTION (the plan's "never yield between LL and SC" was
    imprecise -- other agents MUST interleave at that boundary to detect
    contention).

REPLACE WITH:
  - **Phase 3 -- LL/SC cross-CPU interlock (THE cliff):** per-CPU
    `lock_flag`/`lock_physical_address`, granule CONFIRMED 64B (`pa & ~0x3F`, EV6
    Dcache block per HRM 4.6); any store (STx, STx_C, DMA) by any agent clears other
    CPUs' lock_flag on that granule via clearLine (the invalidating-probe broadcast;
    per-CPU register model is faithful -- owner-table RETRACTED). Dedicated micro-
    test non-negotiable (both-win = corruption; livelock = looks like a hang; 3-CPU
    variant measures the min safe quantum). LL/SC split FSM: never yield MID-
    INSTRUCTION (agents interleave at the LL->SC boundary to detect contention);
    STx_C adjudicated at syncPhase, fixed agent order, committed state (B1/B2 -> bit-
    identical Threaded vs Sequential). Deadlock impossible by construction; only duty
    = no false STx_C success. BLOCKING CONFIRM: LockMonitor (memoryLib, single source
    of truth) vs LockArbiter (schedLib) reconciliation before any seam edit. New
    ledger: Restriction 23 same-CPU intervening-op clearing (_PROVISIONAL). Full
    record: journals/20260628_llsc_reservation_model_and_barrier_analysis.md.
